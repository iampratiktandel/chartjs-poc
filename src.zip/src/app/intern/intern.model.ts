export interface Intern {
  city: string;
  department: string;
  email: string;
  gender: string;
  hireDate: string;
  id: number;
  mobile: string;
  name: string;
  permanent: boolean;
}