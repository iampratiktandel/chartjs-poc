import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-intern',
  templateUrl: './intern.component.html',
  styleUrls: ['./intern.component.css']
})
export class InternComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
